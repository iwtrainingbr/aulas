const INPUT_NUMERO = document.getElementById('numero');
const INPUT_TITULAR = document.getElementById('titular');
const INPUT_CPF = document.getElementById('cpf');
const SELECT_MES = document.getElementById('mes');
const SELECT_ANO = document.getElementById('ano');
const INPUT_CVV = document.getElementById('cvv');

const CARD_BANDEIRA = document.getElementById('card-bandeira');
const CARD_NUMERO = document.getElementById('card-numero');
const CARD_TITULAR = document.getElementById('card-titular');
const CARD_VENCIMENTO = document.getElementById('card-vencimento');

INPUT_NUMERO.addEventListener('keyup', function () {
  CARD_NUMERO.innerHTML = INPUT_NUMERO.value;

  let primeiroDigito = INPUT_NUMERO.value[0];

  let bandeiras = {
    3: 'AMEX',
    4: '<img width="70px" src="img/visa.png">',
    5: '<img width="70px" src="img/mastercard.png">',
    6: 'GOOGLE',
    7: 'BITCOIN',
  };

  CARD_BANDEIRA.innerHTML = bandeiras[primeiroDigito] || 'OUTRO';
});

INPUT_TITULAR.addEventListener('keyup', function () {
  INPUT_TITULAR.value = INPUT_TITULAR.value.toUpperCase();

  CARD_TITULAR.innerHTML = INPUT_TITULAR.value;
});

SELECT_ANO.addEventListener('change', function () {
  // CARD_VENCIMENTO.innerHTML = SELECT_ANO.value[2] + SELECT_ANO.value[3];
  CARD_VENCIMENTO.innerHTML = SELECT_ANO.value.substr(-2);
});

SELECT_MES.addEventListener('change', function () {
  CARD_VENCIMENTO.innerHTML = SELECT_MES.value;
});

// let ano = 2022;
// while (ano <= 2030) {
//   SELECT_ANO.innerHTML += `<option>${ano}</option>`;
//
//   ++ano;
// }

for (let ano = 2022; ano <= 2030; ano++) {
  SELECT_ANO.innerHTML += `<option>${ano}</option>`;
}

let meses = [
  'Janeiro',
  'Fevereiro',
  'Março',
  'Abril',
  'Maio',
  'Junho',
  'Julho',
  'Agosto',
  'Setembro',
  'Outubro',
  'Novembro',
  'Dezembro',
];

meses.map(function (cadaMes, indice) {
  SELECT_MES.innerHTML += `<option value="${indice+1}">${cadaMes}</option>`;
});



// for (let i = 0; i <= 11; i++) {
//   SELECT_MES.innerHTML += `<option>${meses[i]}</option>`;
// }


// for (let mes = 1; mes <= 12; mes++) {
//   SELECT_MES.innerHTML += `<option>${mes}</option>`;
// }
